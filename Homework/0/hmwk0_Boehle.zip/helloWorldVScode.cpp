#include <iostream>
using namespace std;

int main()
{
    cout << "Hello CSCI1300 from VS code" << endl;
    return 0;
}