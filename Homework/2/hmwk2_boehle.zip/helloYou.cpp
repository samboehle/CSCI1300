// CSCI1300 Spring 2020
// Author: Samuel Boehle
//Recitation: 101 - James Watson
//Homework #2 - Problem #2


#include <iostream>
#include <string>

using namespace std;

int main()
{
    cout << "Enter your name:" << endl;
    
    string name;
    cin >> name;

    cout << "Hello, " + name + "!" << endl;
    return 0;
}
