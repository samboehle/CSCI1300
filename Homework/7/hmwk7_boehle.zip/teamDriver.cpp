// CSCI1300 Spring 2020
// Author: Samuel Boehle
//Recitation: 101 - James Watson
//Homework #7 - Problem #2

#include <iostream>
#include <fstream>
using namespace std;
#include "Team.h"

int main()
{
/*//using parametized constructor
    Team team4("Thats so Ravenclaw");
    cout << team4.getTeamName() << endl;

    //using readroster
    team4.readRoster("roster1.txt");
    
    int n4 = team4.getNumPlayers();

    //using for loop to output names and player points
    for (int i = 0; i < n4; i++) {
        cout << team4.getPlayerName(i) << " ";
        cout << team4.getPlayerPoints(i) << endl;
    }*/
    return 0;
}