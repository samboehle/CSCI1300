// CSCI1300 Spring 2020
// Author: Samuel Boehle
//Recitation: 101 - James Watson
//Homework #7 - Problem #1

#include <iostream>
#include "Player.h"
using namespace std;

int main()
{
    /*//Testing default contstructors
    Player bob;
    cout << bob.getName() << endl;
    cout << bob.getPoints() << endl;
    //Testing paramatized constructor
    Player bruh("bob", 70);
    cout << bruh.getName() << endl;
    cout << bruh.getPoints() << endl;
    //Testing the other members
    Player jim;
    jim.setName("bob");
    jim.setPoints(70);
    cout << jim.getName() << endl;
    cout << jim.getPoints() << endl;*/

    return 0;
}